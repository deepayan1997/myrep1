sap.ui.jsview("philips.mm.view.Main",
{
	getControllerName : function()
	{
		return "philips.mm.controller.Main";
	},
	createContent:function(oController)
	{
		var oField = new sap.m.Input("idInput",
		{
			width:"250px"
		}
		);
	var oBtn =  new sap.m.Button("idBtn",
		{
			text:"click me",
			press: oController.clickme,
			type:sap.m.ButtonType.Critical
			
		});
		return [oField,oBtn];
	}
});