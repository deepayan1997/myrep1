sap.ui.define(
	["sap/ui/core/mvc/Controller"],
function(oController)
{
return oController.extend("philips.mm.controller.Main",{
	onInit: function()
	{
		
	},
	clickme:function()
	{
		//alert("created using controller");
		$("#idBtn").fadeOut(3000);
		
	}
});	
});