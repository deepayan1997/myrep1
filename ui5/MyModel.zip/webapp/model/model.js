sap.ui.define(
	[],
	 function(){
	 	return{
	 		createMyModel:function()
	 		{
	 		var oModel = new sap.ui.model.json.JSONModel();
			oModel.loadData("model/data/mockdata.json");
			return oModel;
	 		}
	 	};
	 	
	 }	
);